package com.hackhub.hackhub.state;
import com.hackhub.hackhub.model.Hackathon;
import com.hackhub.hackhub.model.Team;

public class StatoInIscrizione implements HackathonState {
    @Override
    public void iscriviTeam(Hackathon h, Team t) {
        h.getTeamsIscritti().add(t);
        t.setHackathon(h); // Aggiorno anche il lato del team
    }

    @Override
    public void avanzaStato(Hackathon h) {
        h.setTipoStato(TipoStato.IN_CORSO);
        // Qui metteresti new StatoInCorso() quando lo creerai
    }
    @Override
    public void uploadSottomissione(Hackathon h) {
        throw new RuntimeException("Errore: Non puoi inviare lavori adesso. L'Hackathon non è In Corso!");
    }
}
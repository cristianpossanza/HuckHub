package com.hackhub.hackhub.service;

import com.hackhub.hackhub.dto.CreaHackathonDTO;
import com.hackhub.hackhub.model.Hackathon;
import com.hackhub.hackhub.model.Utente;
import com.hackhub.hackhub.repository.HackathonRepository;
import com.hackhub.hackhub.repository.UtenteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class HackathonService {

    @Autowired private HackathonRepository hackathonRepo;
    @Autowired private UtenteRepository utenteRepo;

    public Hackathon creaHackathon(CreaHackathonDTO dto) {
        Utente org = utenteRepo.findById(dto.getOrganizzatoreId())
                .orElseThrow(() -> new RuntimeException("Organizzatore non trovato"));

        Hackathon h = new Hackathon(
                dto.getTitolo(), dto.getRegolamento(), dto.getLuogo(),
                dto.getPremio(), dto.getMaxTeamSize(), org
        );
        return hackathonRepo.save(h);
    }

    public void apriIscrizioni(Long hackathonId) {
        Hackathon h = hackathonRepo.findById(hackathonId)
                .orElseThrow(() -> new RuntimeException("Hackathon non trovato"));
        h.avanzaStato();
        hackathonRepo.save(h);
    }
}
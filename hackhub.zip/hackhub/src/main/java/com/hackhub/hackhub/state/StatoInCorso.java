package com.hackhub.hackhub.state;

import com.hackhub.hackhub.model.Hackathon;
import com.hackhub.hackhub.model.Team;

public class StatoInCorso implements HackathonState {

    @Override
    public void iscriviTeam(Hackathon h, Team t) {
        throw new RuntimeException("Errore: Le iscrizioni sono CHIUSE. L'evento è in corso.");
    }

    @Override
    public void avanzaStato(Hackathon h) {
        h.setTipoStato(TipoStato.IN_VALUTAZIONE);
        // h.setStatoComportamento(new StatoInValutazione()); // Lo creeremo dopo
    }

    @Override
    public void uploadSottomissione(Hackathon h) {
        // QUI SI PUO' FARE! Non lancia eccezioni.
        // Potresti aggiungere un controllo per verificare che la "dataFine" non sia passata.
    }
}
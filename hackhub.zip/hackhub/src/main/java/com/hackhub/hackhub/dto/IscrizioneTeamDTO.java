package com.hackhub.hackhub.dto;

public class IscrizioneTeamDTO {
    private Long teamId;
    private Long hackathonId;
    private Long utenteId; // Colui che clicca il bottone "Iscriviti"

    // Getter e Setter
    public Long getTeamId() { return teamId; }
    public void setTeamId(Long teamId) { this.teamId = teamId; }
    public Long getHackathonId() { return hackathonId; }
    public void setHackathonId(Long hackathonId) { this.hackathonId = hackathonId; }
    public Long getUtenteId() { return utenteId; }
    public void setUtenteId(Long utenteId) { this.utenteId = utenteId; }
}
package com.hackhub.hackhub.state;
import com.hackhub.hackhub.model.Hackathon;
import com.hackhub.hackhub.model.Team;

public interface HackathonState {
    void iscriviTeam(Hackathon h, Team t);
    void avanzaStato(Hackathon h);
    void uploadSottomissione(Hackathon h);
}
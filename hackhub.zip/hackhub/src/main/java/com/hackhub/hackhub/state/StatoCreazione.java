package com.hackhub.hackhub.state;
import com.hackhub.hackhub.model.Hackathon;
import com.hackhub.hackhub.model.Team;

public class StatoCreazione implements HackathonState {
    @Override
    public void iscriviTeam(Hackathon h, Team t) {
        throw new RuntimeException("Errore: Hackathon non ancora aperto alle iscrizioni!");
    }

    @Override
    public void avanzaStato(Hackathon h) {
        h.setTipoStato(TipoStato.IN_ISCRIZIONE);
        h.setStatoComportamento(new StatoInIscrizione());
    }

    @Override
    public void uploadSottomissione(Hackathon h) {
        throw new RuntimeException("Errore: Non puoi inviare lavori adesso. L'Hackathon non è In Corso!");
    }
}
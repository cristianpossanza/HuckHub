package com.hackhub.hackhub.controller;

import com.hackhub.hackhub.dto.CreaSottomissioneDTO;
import com.hackhub.hackhub.dto.CreaTracciaDTO;
import com.hackhub.hackhub.model.Sottomissione;
import com.hackhub.hackhub.model.Traccia;
import com.hackhub.hackhub.service.SottomissioneService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/lavori")
public class SottomissioneController {

    @Autowired
    private SottomissioneService sottomissioneService;

    @PostMapping("/crea-traccia")
    public ResponseEntity<?> creaTraccia(@RequestBody CreaTracciaDTO dto) {
        try {
            Traccia t = sottomissioneService.creaTraccia(dto);
            return ResponseEntity.ok("Traccia '" + t.getTitolo() + "' creata! ID: " + t.getId());
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PostMapping("/invia-sottomissione")
    public ResponseEntity<?> inviaSottomissione(@RequestBody CreaSottomissioneDTO dto) {
        try {
            Sottomissione s = sottomissioneService.gestisciSottomissione(dto);
            String msg = dto.isDefinitiva() ? "Consegna DEFINITIVA effettuata!" : "Bozza SALVATA con successo.";
            return ResponseEntity.ok(msg + " ID Sottomissione: " + s.getId());
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}
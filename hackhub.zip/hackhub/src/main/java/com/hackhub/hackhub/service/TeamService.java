package com.hackhub.hackhub.service;


import com.hackhub.hackhub.dto.AggiungiMembroDTO;
import com.hackhub.hackhub.dto.CreaTeamDTO;
import com.hackhub.hackhub.dto.IscrizioneTeamDTO;
import com.hackhub.hackhub.model.Hackathon;
import com.hackhub.hackhub.model.Team;
import com.hackhub.hackhub.model.Utente;
import com.hackhub.hackhub.repository.TeamRepository;
import com.hackhub.hackhub.repository.UtenteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class TeamService {
    @Autowired private com.hackhub.hackhub.repository.HackathonRepository hackathonRepository;
    @Autowired private TeamRepository teamRepository;
    @Autowired private UtenteRepository utenteRepository;

    @Transactional // Se c'è un errore, annulla tutte le modifiche al DB!
    public Team creaTeam(CreaTeamDTO dto) {

        // 1. Cerco l'utente che vuole creare il team
        Utente leader = utenteRepository.findById(dto.getLeaderId())
                .orElseThrow(() -> new RuntimeException("Errore: Utente non trovato!"));

        // 2. Controllo se l'utente è già in un team
        if (leader.getTeam() != null) {
            throw new RuntimeException("Errore: L'utente fa già parte di un team!");
        }

        // 3. Creo il nuovo Team
        Team nuovoTeam = new Team();
        nuovoTeam.setNome(dto.getNomeTeam());
        nuovoTeam.setLeader(leader);

        // 4. Aggiungo il leader alla lista dei membri
        nuovoTeam.getMembri().add(leader);

        // 5. Salvo il team nel DB
        Team teamSalvato = teamRepository.save(nuovoTeam);

        // 6. Aggiorno l'utente: ora appartiene a questo team
        leader.setTeam(teamSalvato);
        utenteRepository.save(leader); // Salvo la modifica sull'utente

        return teamSalvato;
    }
    @Transactional
    public void aggiungiMembro(AggiungiMembroDTO dto) {
        // 1. Recupero il Team dal DB
        Team team = teamRepository.findById(dto.getTeamId())
                .orElseThrow(() -> new RuntimeException("Errore: Team non trovato!"));

        // 2. Recupero l'Utente dal DB
        Utente nuovoMembro = utenteRepository.findById(dto.getUtenteId())
                .orElseThrow(() -> new RuntimeException("Errore: Utente non trovato!"));

        // 3. Controllo di business fondamentale (La traccia dice: un solo team alla volta)
        if (nuovoMembro.getTeam() != null) {
            throw new RuntimeException("Errore: L'utente " + nuovoMembro.getNome() + " fa già parte di un team!");
        }

        // 4. Aggiorno le relazioni (Sia lato Utente che lato Team)
        nuovoMembro.setTeam(team);
        team.getMembri().add(nuovoMembro);

        // 5. Salvo nel database (JPA salverà automaticamente l'utente aggiornato)
        utenteRepository.save(nuovoMembro);
    }
    @Transactional
    public void iscriviTeamAdHackathon(IscrizioneTeamDTO dto) {
        // 1. Recupero dal Database
        Team team = teamRepository.findById(dto.getTeamId())
                .orElseThrow(() -> new RuntimeException("Errore: Team non trovato!"));

        Hackathon hackathon = hackathonRepository.findById(dto.getHackathonId())
                .orElseThrow(() -> new RuntimeException("Errore: Hackathon non trovato!"));

        Utente utente = utenteRepository.findById(dto.getUtenteId())
                .orElseThrow(() -> new RuntimeException("Errore: Utente non trovato!"));

        // 2. Controllo di Business: Solo il Leader può iscrivere il team
        if (!team.getLeader().getId().equals(utente.getId())) {
            throw new RuntimeException("Errore Sicurezza: Solo il leader del team può effettuare l'iscrizione.");
        }

        // 3. IL PATTERN STATE IN AZIONE!
        // Chiamando questo metodo, l'Hackathon delegherà il controllo al suo "statoCorrente".
        // Se è "CREAZIONE" o "IN_CORSO" lancerà un'eccezione in automatico bloccando tutto!
        hackathon.iscriviTeam(team);

        // 4. Salvataggio nel Database
        // In JPA, salvando il "lato proprietario" (Team) si salva la relazione.
        teamRepository.save(team);
    }
}
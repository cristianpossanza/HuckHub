package com.hackhub.hackhub.model;

import com.hackhub.hackhub.state.*;
import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
public class Hackathon {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String titolo;
    private String regolamento;
    private String luogo;
    private double premio;
    private int maxTeamSize;

    // --- LE RELAZIONI ---
    @ManyToOne
    @JoinColumn(name = "organizzatore_id")
    private Utente organizzatore;

    @OneToMany(mappedBy = "hackathon", cascade = CascadeType.ALL)
    private List<Team> teamsIscritti = new ArrayList<>();

    // --- IL TRUCCO DELLO STATE PATTERN ---

    @Enumerated(EnumType.STRING)
    private TipoStato tipoStato; // QUESTO VIENE SALVATO NEL DATABASE (Es. "CREAZIONE")

    @Transient // QUESTO NON VIENE SALVATO NEL DB, VIVE SOLO IN RAM!
    private HackathonState statoComportamento;

    public Hackathon() {}

    public Hackathon(String titolo, String regolamento, String luogo, double premio, int maxTeamSize, Utente org) {
        this.titolo = titolo;
        this.regolamento = regolamento;
        this.luogo = luogo;
        this.premio = premio;
        this.maxTeamSize = maxTeamSize;
        this.organizzatore = org;
        this.tipoStato = TipoStato.CREAZIONE;
        this.statoComportamento = new StatoCreazione();
    }

    // MAGIA DI SPRING: Appena legge la riga dal Database, esegue questo metodo
    // per "resuscitare" l'oggetto State corretto!
    // MAGIA DI SPRING: Ricarica lo stato corretto dal DB alla RAM
    @PostLoad
    public void initStatoDopoCaricamento() {
        if (this.tipoStato == null) return;

        switch (this.tipoStato) {
            case CREAZIONE:
                this.statoComportamento = new StatoCreazione();
                break;
            case IN_ISCRIZIONE:
                this.statoComportamento = new StatoInIscrizione();
                break;
            case IN_CORSO:
                this.statoComportamento = new StatoInCorso(); // ORA LO TROVA!
                break;
            case IN_VALUTAZIONE:
                // Se non hai ancora creato la classe StatoInValutazione.java, commenta questa riga per ora
                // this.statoComportamento = new StatoInValutazione();
                break;
            case CONCLUSO:
                // this.statoComportamento = new StatoConcluso();
                break;
        }
    }

    // --- DELEGAZIONE (Il Pattern in azione) ---
    public void iscriviTeam(Team t) {
        if (t.getMembri().size() > this.maxTeamSize) {
            throw new RuntimeException("Team troppo numeroso per questo Hackathon!");
        }
        this.statoComportamento.iscriviTeam(this, t);
    }

    public void avanzaStato() {
        this.statoComportamento.avanzaStato(this);
    }
// ... altri metodi (iscriviTeam, avanzaStato, ecc) ...

    public void uploadSottomissione() {
        // L'Hackathon delega il controllo al suo stato corrente!
        this.statoComportamento.uploadSottomissione(this);
    }
    // --- GETTER E SETTER (Base) ---
    public Long getId() { return id; }
    public String getTitolo() { return titolo; }
    public Utente getOrganizzatore() { return organizzatore; }
    public List<Team> getTeamsIscritti() { return teamsIscritti; }

    public void setTipoStato(TipoStato tipoStato) { this.tipoStato = tipoStato; }
    public void setStatoComportamento(HackathonState stato) { this.statoComportamento = stato; }
    public TipoStato getTipoStato() { return tipoStato; }
}

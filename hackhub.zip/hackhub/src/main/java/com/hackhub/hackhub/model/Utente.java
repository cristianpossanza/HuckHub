package com.hackhub.hackhub.model;

import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity // Dice a Spring: "Crea una tabella chiamata Utente"
public class Utente {

    @Id // Chiave Primaria
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Auto-increment
    private Long id;

    private String nome;

    @Column(unique = true, nullable = false)
    private String email;

    private String password;

    // Relazione: Molti utenti possono stare in Un team
    @ManyToOne
    @JoinColumn(name = "team_id")
    @JsonIgnore // Evita loop infiniti quando Postman legge i dati
    private Team team;

    // Costruttore vuoto obbligatorio per Spring JPA
    public Utente() {}

    public Utente(String nome, String email, String password) {
        this.nome = nome;
        this.email = email;
        this.password = password;
    }

    // --- GETTER E SETTER ---
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    public Team getTeam() { return team; }
    public void setTeam(Team team) { this.team = team; }
}
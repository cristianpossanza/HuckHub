package com.hackhub.hackhub.dto;

public class CreaHackathonDTO {
    private String titolo;
    private String regolamento;
    private String luogo;
    private double premio;
    private int maxTeamSize;
    private Long organizzatoreId;

    // Aggiungi tutti i Getter e Setter!
    public String getTitolo() { return titolo; } public void setTitolo(String t) { titolo = t; }
    public String getRegolamento() { return regolamento; } public void setRegolamento(String r) { regolamento = r; }
    public String getLuogo() { return luogo; } public void setLuogo(String l) { luogo = l; }
    public double getPremio() { return premio; } public void setPremio(double p) { premio = p; }
    public int getMaxTeamSize() { return maxTeamSize; } public void setMaxTeamSize(int m) { maxTeamSize = m; }
    public Long getOrganizzatoreId() { return organizzatoreId; } public void setOrganizzatoreId(Long id) { organizzatoreId = id; }
}
package com.hackhub.hackhub.controller;

import com.hackhub.hackhub.dto.CreaHackathonDTO;
import com.hackhub.hackhub.model.Hackathon;
import com.hackhub.hackhub.service.HackathonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/hackathons")
public class HackathonController {

    @Autowired
    private HackathonService hackathonService;

    @PostMapping("/crea")
    public ResponseEntity<?> crea(@RequestBody CreaHackathonDTO dto) {
        try {
            Hackathon h = hackathonService.creaHackathon(dto);
            return ResponseEntity.ok("Hackathon Creato! ID: " + h.getId() + " - Stato: " + h.getTipoStato());
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    // Endpoint per mandare avanti lo stato (simula il tempo o l'azione manuale)
    @PostMapping("/{id}/apri-iscrizioni")
    public ResponseEntity<?> apriIscrizioni(@PathVariable Long id) {
        try {
            hackathonService.apriIscrizioni(id);
            return ResponseEntity.ok("Iscrizioni aperte per l'hackathon " + id);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}
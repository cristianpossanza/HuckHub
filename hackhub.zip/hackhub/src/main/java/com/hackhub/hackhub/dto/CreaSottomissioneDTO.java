package com.hackhub.hackhub.dto;

public class CreaSottomissioneDTO {
    private Long tracciaId;
    private Long utenteId; // Chi fa materialmente l'upload
    private String testoSoluzione;
    private String urlProgetto;
    private boolean definitiva; // Se true, non potrà più essere modificata

    public Long getTracciaId() { return tracciaId; }
    public void setTracciaId(Long tracciaId) { this.tracciaId = tracciaId; }
    public Long getUtenteId() { return utenteId; }
    public void setUtenteId(Long utenteId) { this.utenteId = utenteId; }
    public String getTestoSoluzione() { return testoSoluzione; }
    public void setTestoSoluzione(String testoSoluzione) { this.testoSoluzione = testoSoluzione; }
    public String getUrlProgetto() { return urlProgetto; }
    public void setUrlProgetto(String urlProgetto) { this.urlProgetto = urlProgetto; }
    public boolean isDefinitiva() { return definitiva; }
    public void setDefinitiva(boolean definitiva) { this.definitiva = definitiva; }
}
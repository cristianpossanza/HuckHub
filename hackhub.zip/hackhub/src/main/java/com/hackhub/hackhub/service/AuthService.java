package com.hackhub.hackhub.service;


import com.hackhub.hackhub.dto.RegistrazioneDTO;
import com.hackhub.hackhub.model.Utente;
import com.hackhub.hackhub.repository.UtenteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service // Dice a Spring che questa è la logica di business
public class AuthService {

    @Autowired // Spring inietta automaticamente il Database qui!
    private UtenteRepository utenteRepository;

    public Utente registraUtente(RegistrazioneDTO dto) {
        // 1. Controllo se l'email esiste già
        if (utenteRepository.findByEmail(dto.getEmail()).isPresent()) {
            throw new RuntimeException("Errore: Email già registrata!");
        }

        // 2. Creo la Entity (Il modello da salvare)
        Utente nuovoUtente = new Utente(dto.getNome(), dto.getEmail(), dto.getPassword());

        // 3. Salvo nel Database
        return utenteRepository.save(nuovoUtente);
    }
}